type Author = {
    id: number,
    name: string,
    surname: string,
    avatar: string
}

export default Author