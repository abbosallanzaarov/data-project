<script lang="ts">
    export let name: string
</script>

<button class="btn bg-base-300 btn-sm rounded-lg text-xs lowercase">{name}</button>