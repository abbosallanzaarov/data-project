<script>
    import Projects from "../components/Projects.svelte";
    import Categories from "../components/Categories.svelte";
</script>

<div>
    <Categories/>
    <Projects/>
</div>
